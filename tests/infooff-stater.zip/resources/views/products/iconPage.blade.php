<div>
    <div class="w-[180px] h-[180px] rounded-md bg-slate-200 absolute top-[-100px] md:top-[-80px] left-[50px]"></div>
    <div
      class="hidden sm:block sm:w-[300px] md:w-[400px] lg:w-[600px]  h-[120px]
        rounded-md bg-slate-300 absolute top-[-100px] md:top-[-80px] right-[50px]"
    ></div>
  </div>
