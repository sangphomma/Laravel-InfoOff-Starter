<div class='w-full py-3 px-[10%] m-auto bg-blue-400' ><span class='font-thin text-white ' >Footer</span></div>
