<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <div class='flex flex-col w-screen min-h-screen ' >
        <div >

            <?php echo $__env->make('layouts.products.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class='flex-1 flex flex-col' >

            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div >
            <?php echo $__env->make('layouts.products.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\PREDATOR\Desktop\@RealStart\infoOff\resources\views/layouts/products/index.blade.php ENDPATH**/ ?>