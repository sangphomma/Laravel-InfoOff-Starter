<div>
    <div class="w-full px-[10%] md:px-[7%] bg-blue-400 relative flex ">
        <div class='p-6' ></div>
    </div>
</div>
<?php /**PATH C:\Users\PREDATOR\Desktop\@RealStart\infoOff\resources\views/layouts/products/heroZone.blade.php ENDPATH**/ ?>